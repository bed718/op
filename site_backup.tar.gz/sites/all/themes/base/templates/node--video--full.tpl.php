<div class="video-full ">
	<h2><?php print $title; ?></h2>
	<div class="video"><?php print $video; ?></div>
	<div class="body"><?php print $body; ?></div>
</div>
<div class="divider"><span></span></div>