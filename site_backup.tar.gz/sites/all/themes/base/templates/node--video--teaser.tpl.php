<div class="video-teaser ">
	<div class="image"><?php print $cover_image; ?></div>
	<h2><a href="<?php print $url; ?>"><?php print $title; ?></a></h2>
</div>
