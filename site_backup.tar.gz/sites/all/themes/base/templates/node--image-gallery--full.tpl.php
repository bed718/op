<div class="gallery-full gallery">
	<div class="images"><?php print $images; ?></div>
	<div class="controls">
		<div class="last-item"></div>
		<div class="next-item"></div>
	</div>
</div>
