<div class="post-teaser post">
	<div class="header">
		<div class="post-date"><?php print $created_month; ?><span><?php print $created_day; ?></span></div>
	</div>
	<div class="body"><?php print $body; ?></div>
</div>
