<div class="gallery-featured ">
	<div class="images"><?php print $images; ?></div>
</div>

<div class="btn-main"><a href="/images">more images</a></div>
<div class="divider"><span></span></div>