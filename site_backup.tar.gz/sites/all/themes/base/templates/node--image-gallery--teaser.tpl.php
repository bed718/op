<div class="gallery-teaser gallery">
	<h2><a href="<?php print $url; ?>"><?php print $title; ?></a></h2>
	<div class="images"><?php print $images; ?></div>
</div>

<div class="btn-main"><a href="<?php print $url; ?>">more <?php print $title; ?></a></div>
<div class="divider"><span></span></div>