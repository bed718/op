<div class="video-featured ">
	<div class="image"><?php print $cover_image; ?></div>
</div>

<div class="btn-main"><a href="/clips">more clips</a></div>
<div class="divider"><span></span></div>