<div class="comment">
	<div class="comment-header clearfix">
		<div class="title"><?php echo $title; ?></div>
		<div class="website"><?php echo $website; ?></div>
	</div>
	<div class="submitted">
		<?php echo $submitted; ?>
	</div>
	<div class="body clearfix">
		<div class="quo-mark">&ldquo;</div>
		<?php echo $body; ?>
	</div>
</div>