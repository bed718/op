(function ($) {
  Drupal.behaviors.ws_lsb = {
    attach: function (context, settings) {
      $('a.service-links-linkedin-share-button', context).each(function(){
        var script_obj = document.createElement('script');
        script_obj.type = 'IN/Share';
        script_obj.setAttribute("data-url", $(this).attr('href'));
        if (Drupal.settings.ws_lsb.countmode != '') {
          script_obj.setAttribute("data-counter", Drupal.settings.ws_lsb.countmode);
        }
        $(this).replaceWith(script_obj);
      });

      try {
        IN.init({
          onLoad: "Drupal.behaviors.ws_lsb.parse"
        });
      }
      catch(e) {
        if (window.console && window.console.log) {
          console.log(e);
        }
      }
    },

    parse: function(context) {
      try {
        IN.parse(context);
      }
      catch(e) {
        if (window.console && window.console.log) {
          console.log(e);
        }
      }
    }
  }
})(jQuery);
